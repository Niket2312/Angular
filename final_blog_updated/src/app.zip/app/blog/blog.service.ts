import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class BlogService{
    blog=[{
        id:1,
        title:"Niket",
        description:"description1",
        imageurl:"https://static.vecteezy.com/packs/media/components/global/search-explore-nav/img/vectors/term-bg-1-666de2d941529c25aa511dc18d727160.jpg",
        languages:[{language_id:1,language_text:"Angular"}],
        author:"niket",
        date:"23-12-2000"
    }]
    getData(form:any){
        console.log(form);
        this.blog.push(form)
        console.log(this.blog);    
    }
    getId(id:number){
        return this.blog.find(x=>x.id==id)
    }
    getLength(){
        return this.blog.length
    }
}