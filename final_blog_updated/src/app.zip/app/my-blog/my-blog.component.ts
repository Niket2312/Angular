import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { LoginService } from '../login.service';
@Component({
  selector: 'app-my-blog',
  templateUrl: './my-blog.component.html',
  styleUrls: ['./my-blog.component.css']
})
export class MyBlogComponent implements OnInit {
username:any
  constructor(public loginservice:LoginService) {
    this.username=this.loginservice.username
    console.log(this.username);
   }
  
  
  ngOnInit(): void {
    this.username=this.loginservice.username

    console.log(this.username);

  }
  

}
